//
// Created by mwypych on 02.02.17.
//

#ifndef JIMP_EXERCISES_FACTORIAL_H
#define JIMP_EXERCISES_FACTORIAL_H

int factorial(int value);

#endif //JIMP_EXERCISES_FACTORIAL_H
