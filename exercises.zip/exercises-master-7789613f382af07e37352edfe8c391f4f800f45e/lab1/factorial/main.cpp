#include <iostream>
#include "Factorial.h"

int main() {
  std::cout << "factorial of 20 is: " << factorial(20) << std::endl;
  return 0;
}
