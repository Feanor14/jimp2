//
// Created by mwypych on 10.03.18.
//

#ifndef JIMP_EXERCISES_EXAMPLETASK_H
#define JIMP_EXERCISES_EXAMPLETASK_H

#include <string>

int ExampleAddition(int x, int y);

std::string ExampleConcatenation(const std::string& left, const std::string &right);

#endif //JIMP_EXERCISES_EXAMPLETASK_H
